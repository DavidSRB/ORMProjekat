#include <iostream>
#include <string.h>
#include <sstream>
#include <sys/socket.h>
#include <arpa/inet.h> //inet_addr
#include <unistd.h>
#include <pthread.h>
#include <vector>

#include "user.hpp"

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT   27015


std::vector<User> users = {User((char*)"branko", 12345678, 2222, 1253.3),
                           User((char*)"david", 98765432, 1111, 5253.3), 
                           User((char*)"mika", 45678912, 6666, 253.3)};

void SendData(char* message, int sock){
    if( send(sock , message , strlen(message), 0) < 0)
    {
        puts("Send failed");
        exit(1);
    }
}

unsigned int ConvertMessage(const char* message) {
    unsigned int ret;
    sscanf(message, "%d", &ret);
    return ret;
}

char* ConvertInt(double number) {
    std::stringstream strs;
    strs << number;
    std::string temp_str = strs.str();
    char* char_type = (char*) temp_str.c_str();

    return char_type;
}

int FindUser(const char* identification) {
    int pos = -1;
    unsigned int id = ConvertMessage(identification);

    for(unsigned int i = 0; i < users.size(); ++i) {
        if( ((strcmp(users[i].GetUsername(), identification) == 0) || (users[i].GetId() == id)) && !users[i].GetLogin() ) {
            pos = i;
            users[i].SetLogin();
            break;
        }
    }

    return pos;
}

bool ProcessOption(unsigned int option, unsigned num, int position) {

    switch (option) {
        case 1: // set new pin
            if( users[position].GetPin() ==  num) { // ne moze vise od cifre 
                return false;
            }
            users[position].SetPin(num);
            break;
        case 3: // withdraw money
            if((double)num > users[position].GetBalance())
                return false;

            std::cout << num << std::endl;
            
            users[position].SetBalance( users[position].GetBalance() - (double) num );

            break;
        default:
            std::cout << "Greska" << std::endl;
    }

    return true;

}

void* func(void* args){
    char client_message[DEFAULT_BUFLEN];
    char server_message[DEFAULT_BUFLEN];

    int client_sock = *((int*)(&args));
    int position, read_size;


    //receive and check username or id
    do{
    
        read_size = recv(client_sock , client_message , DEFAULT_BUFLEN , 0);
        client_message[read_size] = 0;

        position = FindUser(client_message);

        if(position >= 0)
            strcpy(server_message, "ACCEPT");
        else 
            strcpy(server_message, "DECLINE");

        SendData(server_message,client_sock);

        std::cout << server_message << std::endl;

    } while(strcmp(server_message, "ACCEPT") != 0);




    //receive and check pin
    do { 
        read_size = recv(client_sock , client_message , DEFAULT_BUFLEN , 0);//ako stavis do while stavi i ovde i kod klijenta(ovde ocekujes pin)
        client_message[read_size] = 0;

        if( users[position].GetPin() == ConvertMessage(client_message) )
            strcpy(server_message, "ACCEPT");
        else 
            strcpy(server_message, "DECLINE");

        SendData(server_message , client_sock);
    } while(strcmp(server_message, "ACCEPT") != 0);
    


    // recieve user option and process it
    recv(client_sock , client_message , DEFAULT_BUFLEN , 0);

    unsigned int option = ConvertMessage(client_message) % 10; // option - number of clients option
    unsigned int num = ConvertMessage(client_message) / 10;    //num - NewPin or Amount of Money
  
    if (option != 2) 
        ProcessOption(option, num, position) ? strcpy(server_message, "ACCEPT") : strcpy(server_message, "DECLINE");
    else  {
        strcpy( server_message, ConvertInt(users[position].GetBalance()) );
    }

    SendData(server_message , client_sock);

    users[position].SetLogout();

    return 0;
}

int main(int argc , char *argv[])
{
    int socket_desc , client_sock , c ;
    struct sockaddr_in server , client;
    pthread_t threads[10];//problem sa dinamickom alokacijom(malloc)
   
    //Create socket
    socket_desc = socket(AF_INET , SOCK_STREAM , 0);
    if (socket_desc == -1)
    {
        printf("Could not create socket");
    }
    puts("Socket created");

    //Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(DEFAULT_PORT);

    //Bind
    if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) < 0)
    {
        //print the error message
        perror("bind failed. Error");
        return 1;
    }
    puts("bind done");

    int thread_num = 0;

    //Listen
    listen(socket_desc , 3);
    
    while(1){

        //Accept and incoming connection
        puts("Waiting for incoming connections...");
        c = sizeof(struct sockaddr_in);

        //accept connection from an incoming client
        client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c);
        if (client_sock < 0)
        {
            perror("accept failed");
            return 1;
        }
        puts("Connection accepted");

        pthread_create(&threads[thread_num],NULL,func,(void*)client_sock);
        thread_num++;
    }

    pthread_join(threads[0], NULL);
    pthread_join(threads[1], NULL);

    return 0;
}