#ifndef USER_HPP_
#define USER_HPP_

#include <string>

class User{
    private:
        char* username;
        unsigned int uid;
        unsigned int pin;
        double balance;
        bool login; // true - user login, false - user logout
    public:
        User(char* un, unsigned int id, unsigned int p, double b);

        char* GetUsername();
        unsigned int GetId();
        unsigned int GetPin();
        double GetBalance();
        bool GetLogin();

        void SetPin(unsigned int newPin);
        void SetBalance(double newBalance);
        void SetLogin();
        void SetLogout();
};

#endif