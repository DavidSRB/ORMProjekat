#include <iostream>
#include<sys/socket.h> //socket
#include<arpa/inet.h>  //inet_addr
#include <fcntl.h>     //for open
#include <unistd.h>    //for close
#include <string.h>

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT   27015

void LoginMenu(char* uinput){
    std::cout << "Enter your Username or card ID: \t" << std::endl;
    scanf("%s",uinput);
}

void PinMenu(char* uinput){
    std::cout << "Enter your PIN: \t" << std::endl;
    scanf("%s",uinput);
}

void UserMenu(char* uinput) {
    int option;

    std::cout << "1. Change Pin \n";
    std::cout << "2. Check Status \n";
    std::cout << "3. Withdraw Money\n";

    do {
        std::cout << "Enter option: \t";
        scanf("%d", &option);
    } while (option > 3 || option < 1);

    switch (option) {
        case 1:
            std::cout << "\n" << std::endl;
            std::cout << "Enter New Pin: \t";
            scanf("%s",uinput);
            strcat(uinput, "1");
            break;
        case 2:
            strcpy(uinput, "2");
            break;
        case 3:
            std::cout << "\n" << std::endl;
            std::cout << "Enter Amount: \t";
            scanf("%s",uinput);
            strcat(uinput, "3");
            break;
        default:
            std::cout << "Cao" << std::endl;
    }
}


void SendData(char* message, int sock){
    if( send(sock , message , strlen(message), 0) < 0)
    {
        puts("Send failed");
        exit(1);
    }
}

int main(int argc , char *argv[])
{
    int sock;
    struct sockaddr_in server;
    char uinput[DEFAULT_BUFLEN];    // user input option
    char message[DEFAULT_BUFLEN];   // recieved message from server

    //Create socket
    sock = socket(AF_INET , SOCK_STREAM , 0);
    if (sock == -1)
    {
        printf("Could not create socket");
    }

    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons(DEFAULT_PORT);

    //Connect to remote server
    if (connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
    {
        perror("connect failed. Error");
        return 1;
    }

    // Enter and send username or id
    do {
        LoginMenu(uinput);
        SendData(uinput,sock);

        //Receive identification confirmation
        recv(sock , message , DEFAULT_BUFLEN , 0);
        std::cout << message << std::endl;
    } while(strcmp(message, "ACCEPT") != 0);


    // Enter and send username or id
    PinMenu(uinput);
    SendData(uinput,sock);

    //Receive pin confirmation
    recv(sock , message , DEFAULT_BUFLEN , 0);


    // Enter option and send to server
    UserMenu(uinput);
    SendData(uinput,sock);

    recv(sock , message , DEFAULT_BUFLEN , 0);
    std::cout << message << std::endl;



    close(sock);

    return 0;
}