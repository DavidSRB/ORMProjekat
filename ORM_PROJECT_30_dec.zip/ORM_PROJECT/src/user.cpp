#include "user.hpp"

User::User(char* un, unsigned int id, unsigned int p, double b) {
    username = un;
    uid = id;
    pin = p;
    balance = b;
}

char* User::GetUsername(){
	return username;
}

unsigned int User::GetId(){
	return uid;
}

unsigned int User::GetPin(){
	return pin;
}

double User::GetBalance(){
	return balance;
}

void User::SetPin(unsigned int newPin){
	pin = newPin;
}

void User::SetBalance(double newBalance){
	balance = newBalance;
}

/*
int User::LoginUsername(std::string username){}

int User::LoginId(unsigned int uid){}

int User::Logout(){}

int User::SendPinCode(unsigned int pin){}

int User::PinChange(unsigned int newPin){}

int User::CheckStatus(){}

int User::GetCash(unsigned int value){}
*/