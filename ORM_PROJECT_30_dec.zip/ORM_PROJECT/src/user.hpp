#ifndef USER_HPP_
#define USER_HPP_

#include <string>

class User{
    private:
        char* username;
        unsigned int uid;
        unsigned int pin;
        double balance;
    public:
        User(char* un, unsigned int id, unsigned int p, double b);

        char* GetUsername();
        unsigned int GetId();
        unsigned int GetPin();
        double GetBalance();

        void SetPin(unsigned int newPin);
        void SetBalance(double newBalance);
/*
        int LoginUsername(std::string username);
        int LoginId(unsigned int uid);
        int Logout();
        int SendPinCode(unsigned int pin);
        int PinChange(unsigned int newPin);
        int CheckStatus();
        int GetCash(unsigned int value);
*/
};

#endif