#include <iostream>
#include<sys/socket.h> //socket
#include<arpa/inet.h>  //inet_addr
#include <fcntl.h>     //for open
#include <unistd.h>    //for close
#include <string.h>

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT   27015

std::string LoginMenu(){
    std::string uinput;

    std::cout << "Enter you Username or card ID: \t" << std::endl;
    std::cin >> uinput;

    return uinput;
}

void SendData(char* message, int sock){
    if( send(sock , message , strlen(message), 0) < 0)
    {
        puts("Send failed");
        exit(1);
    }
}

int main(int argc , char *argv[])
{
    int sock;
    struct sockaddr_in server;

    //Create socket
    sock = socket(AF_INET , SOCK_STREAM , 0);
    if (sock == -1)
    {
        printf("Could not create socket");
    }

    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons(DEFAULT_PORT);

    //Connect to remote server
    if (connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
    {
        perror("connect failed. Error");
        return 1;
    }

    std::string temp = LoginMenu();
    
    char uinput[temp.length() + 1];

    strcpy(uinput, temp.c_str());

    //Send some data
    SendData(uinput,sock);

    close(sock);

    return 0;
}