#include "user.hpp"

User::User(char* un, unsigned int id, unsigned int p, double b) {
    username = un;
    uid = id;
    pin = p;
    balance = b;
	login = false;
}

char* User::GetUsername(){
	return username;
}

unsigned int User::GetId(){
	return uid;
}

unsigned int User::GetPin(){
	return pin;
}

double User::GetBalance(){
	return balance;
}

bool User::GetLogin() {
	return login;
}

void User::SetPin(unsigned int newPin){
	pin = newPin;
}

void User::SetBalance(double newBalance){
	balance = newBalance;
}

void User::SetLogin() {
	login = true;
}

void User::SetLogout() {
	login = false;
}

