#ifndef USER_HPP_
#define USER_HPP_

#include <string>

class User{
    private:
        std::string username;
        unsigned int uid;
        int sessionId;
        unsigned int pin;
        double balance;
    public:
        User(std::string username);

        int LoginUsername(std::string username);
        int LoginId(unsigned int uid);
        int Logout();
        int SendPinCode(unsigned int pin);
        int PinChange(unsigned int newPin);
        int CheckStatus();
        int GetCash(unsigned int value);

};

#endif