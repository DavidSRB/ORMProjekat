#ifndef USERS_HPP_
#define USERS_HPP_

#include <vector>
#include "user.hpp"

static std::vector<User> users = {User((char*)"branko", 12345678, 2222, 1253.3),
                           User((char*)"david", 98765432, 1111, 5253.3), 
                           User((char*)"mika", 45678912, 6666, 253.3),
                           User((char*)"djoka", 45278952, 3333, 2533.3)};

#endif